sap.ui.define(["sap/ui/core/mvc/Controller"],e=>{"use strict";return e.extend("com.riztech.ui5app.project1.app.App",{onInit(){console.log("hello App")}})});
//# sourceMappingURL=App.controller.js.map